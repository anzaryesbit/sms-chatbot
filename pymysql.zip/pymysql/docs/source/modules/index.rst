API Reference
-------------

If you are looking for information on a specific function, class or
method, this part of the documentation is for you.

For more information, please read the `Python Database API specification
<https://www.python.org/dev/peps/pep-0249>`_.

.. toctree::
  :maxdepth: 2

  connections
  cursors
